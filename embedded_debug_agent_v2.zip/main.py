
from agent import DebugAgent

if __name__ == "__main__":
    agent = DebugAgent()
    agent.run()
