
class DebugAgent:
    def __init__(self):
        print("DebugAgent initialized")

    def run(self):
        print("Agent running...")
